package testeStefanini;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Page {

		WebDriver driver;
		
		public void abrirsite(String appUrl)  {
			System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
			driver = new ChromeDriver();
		    driver.get(appUrl);
		    driver.manage().window().maximize();
		}
		    public void cadastrarUsuario (String texto) {
	         WebElement cadastrarUsuario = driver.findElement(By.name("form_usuario"));
			cadastrarUsuario.sendKeys(texto);
		    }
		    public void senha(String texto){
				WebElement senha = driver.findElement(By.name("form_senha"));
				senha.sendKeys(texto);
		    }
		    public void nome(String texto){
				WebElement nome = driver.findElement(By.name("form_nome"));
				nome.sendKeys(texto);
				driver.findElement (By.xpath("/html/body/section/section[2]/div/form/table/tbody/tr[7]/td/input")).click();
				driver.findElement (By.xpath("/html/body/section/section[2]/div/p[3]/a")).click();
		    }
} 
