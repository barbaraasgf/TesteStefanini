package testeStefanini;

import cucumber.api.java.es.Dado;
import cucumber.api.java.it.Quando;
import cucumber.api.java.pt.Então;

public class TesteSteps {
	
	
	Page D = new Page();
	
	@Dado("^que o analista acesse o site aprendendo a testar$")
	public void que_o_analista_acesse_o_site_aprendendo_a_testar() throws Throwable {
		D.abrirsite("http://www.aprendendotestar.com.br/treinar-automacao.php");
	 
	}

	@Quando("^preencher os dados para cadastro$")
	public void preencher_os_dados_para_cadastro() throws Throwable {
		
		
		D.cadastrarUsuario("BarbaraAsgf");
		D.senha("1495");
		D.nome("Barbara Santos");
	
	    
	}
	
	@Então("^o cadastro sera realizado$")
	public void o_cadastro_sera_realizado() throws Throwable {
     System.out.println("cadastro realizado");
	
	    
	}



}
